const Pi = 3.1416

function Pipe(){}

/**
 * @param {体积流量 m3/h} qv 
 * @param {流速 m/s} v
 * @return 管道内径 mm 
 */
Pipe.prototype.dimWithV = function(qv,v){
    return 18.8 * Math.sqrt(qv/v)
}

/**
 * @param {体积流量 m3/h} qv 
 * @param {100m允许压降 kPa/100m} p
 * @param {流体密度 kg/m3} density
 * @param {运动粘度 mm2/s} miu
 * @return 管道内径 mm 
 */
Pipe.prototype.dimWithP = function(qv,delta_p,density,miu){
    return 11.4 * density ** 0.207 * miu ** 0.033 * qv ** 0.38 * delta_p **-0.207
}

/**
 * GB/T17395
 * @param {钢管外径 mm} D 
 * @param {钢管公称厚度 mm} delta
 * @param {钢材密度kg/dm3} density 
 * @return 单位长度钢管重量 kg/m 
 */
Pipe.prototype.weight = function(D,delta,density=7.85){
    return Pi * density * (D - delta) * delta / 1000
}

/**
 * @param {钢管外径 mm} D 
 * @param {保温厚度 mm} S
 * @return 保温体积 m3  
 */
Pipe.prototype.vOfInsultion = function(D,delta){
    return Pi * (D + 1.033 * delta) * 1.033 * delta / 1e6
}

/**
 * @param {钢管外径 mm} D 
 * @param {保温厚度 mm} S
 * @return 保温表面积 m2  
 */
Pipe.prototype.sOfInsultion = function(D,delta){
    return Pi * (D + 2.1 * delta + 8.2) / 1e3
}

/**
 * 单管伴热或双管伴热（管径相同，夹角小于90°）
 * @param {主管管外径 mm} D 
 * @param {伴热管外径 mm} D1
 * @return 伴热管道综合外径 mm
 */
Pipe.prototype.dHasHeatingtube = function(D,D1){
    return D + D1 + 10
}

/**
 * 单管伴热或双管伴热（管径相同，夹角大于90°）
 * @param {主管管外径 mm} D 
 * @param {伴热管外径 mm} D1
 * @return 伴热管道综合外径 mm
 */
Pipe.prototype.dHasHeatingtube = function(D,D1){
    return D + 1.5 * D1 + 10
}

/**
 * 查询钢管尺寸，暂时只支持SH/T3405
 * @param {公称直径}DN
 * @return {钢管外径 mm}
 */
Pipe.prototype.dO = function(DN){
    return PipeThk[DN][0]
}

/**
 * 查询钢管尺寸，暂时只支持SH/T3405
 * @param {壁厚等级索引}SCH
 * @return {SCH}
 */
Pipe.prototype.SCH = function(SCH){
    return PipeThk.SCH[SCH]
}

/**
 * 查询钢管尺寸，暂时只支持SH/T3405
 * @param {公称直径}DN
 * @param {壁厚等级索引}SCH
 * @return {管道壁厚 mm}
 */
Pipe.prototype.THK = function(DN,SCH){
    return PipeThk[DN][SCH]
}

function pipeD_V(){
    let qv = Number(document.getElementById('qv_V').value)
    let v = Number(document.getElementById('v_V').value)
    if(qv == '' || v == '') return
    var pipe = new Pipe()
    document.getElementById('dim_V').value = pipe.dimWithV(qv,v).toFixed(2)
}

function pipeD_P(){
    let qv = Number(document.getElementById('qv_P').value)
    let delta_p = Number(document.getElementById('delta_p_P').value)
    let density = Number(document.getElementById('density_P').value)
    let miu = Number(document.getElementById('miu_P').value)
    if(qv == '' || delta_p == '' || density == '' || miu == '') return
    var pipe = new Pipe()
    document.getElementById('dim_P').value = pipe.dimWithP(qv,delta_p,density,miu).toFixed(2)
}

function pipeWeight(){
    let D = Number(document.getElementById('D_W').value)
    let S = Number(document.getElementById('S_W').value)
    let L = Number(document.getElementById('L_W').value)
    if(D == '' || S == '') return
    var pipe = new Pipe()
    document.getElementById('weight1m').value = pipe.weight(D,S).toFixed(2)
    document.getElementById('weight').value = (L * pipe.weight(D,S)).toFixed(2)  
}

function pipeI(){
    let D = Number(document.getElementById('D_I').value)
    let delta = Number(document.getElementById('delta_I').value)
    let L = Number(document.getElementById('L_I').value)
    if(D == '' || delta == '' || L == '') return
    var pipe = new Pipe()
    document.getElementById('V_I').value = (L * pipe.vOfInsultion(D,delta)).toFixed(2)
    document.getElementById('A_I').value = (L * pipe.sOfInsultion(D,delta)).toFixed(2)  
}

function pipeTHK(){
    let DN = document.getElementById('DN_THK').value
    let SCH = Number(document.getElementById('SCH_THK').value)
  
    if(DN == '' || SCH == '') return
    var pipe = new Pipe()
    document.getElementById('DO_THK').value = pipe.dO(DN)

    if(pipe.THK(DN, SCH) === undefined){
        document.getElementById('THK_THK').value = DN + "钢管无" + pipe.SCH(SCH) + "壁厚等级"
        document.getElementById('W_THK').value = ''
    }
    else{
        document.getElementById('THK_THK').value = pipe.THK(DN, SCH)
        document.getElementById('W_THK').value = (pipe.weight(pipe.dO(DN),pipe.THK(DN,SCH))).toFixed(2)    
    }
}