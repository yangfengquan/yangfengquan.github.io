window.onload = function(){
	var index = new Array()
	data.forEach((item)=>{
		if(index.indexOf(item.category) === -1) index.push(item.category)
	})

	var nav = this.document.getElementById('index')

	index.forEach((item)=>{
		var link = this.document.createElement('a')
		link.href = '#'
		//link.onclick = function(){}
		link.setAttribute('onclick','initContent("' + item + '")')
		link.innerHTML = item
		nav.appendChild(link)
		nav.innerHTML += " | "
	})


	nav.innerHTML = nav.innerHTML.substring(0,nav.innerHTML.lastIndexOf('|'))

	this.initContent(index[0])
}

function initContent(index){
	var content = document.getElementById('content')
	content.innerHTML = ''

	data.forEach((item)=>{
		if(item.category === index){
			var piece = document.createElement('div')
			piece.className = "piece"

			var grid

			//title
			grid = document.createElement('div')
			grid.className = "grid"
			var whole = document.createElement('div')
			whole.className = "unit whole"
			var name = document.createElement('p')
			name.className = "name"
			name.innerHTML = item.title
			whole.appendChild(name)
			grid.append(whole)
			piece.appendChild(grid)

			//in
			var len = item.in.length
			for(var i = 0; i < len; ++i){
				if(i % 2 == 0){
					piece.appendChild(grid)
					grid = document.createElement('div')
					grid.className = "grid" 
				}

				var inItemE = document.createElement('div')
				inItemE.className = "unit half"
				inItemE.innerHTML = item.in[i].name + "： "
				var em,f;
				em = item.in[i].type == "select" ?   "select" : "input" 
				f = item.in[i].type == "select" ?   "onchange" : "oninput"
				var input = document.createElement(em)
				input.type = item.in[i].type
				input.id = item.in[i].id
				input.setAttribute(f, item.in[i].func + "()") 

				inItemE.appendChild(input)

				inItemE.innerHTML += " " + item.in[i].unit

				grid.appendChild(inItemE)

				if(i == len - 1) piece.appendChild(grid)
			}
			
			//empty row

			grid = document.createElement('div')
			grid.className = "grid"
			var empty = document.createElement('div')
			empty.className = "unit whole"
			//empty.innerHTML = ""
			grid.appendChild(empty)

			piece.appendChild(grid)

			len = item.out.length
			for(var i = 0; i < len; ++i){
				if(i % 2 == 0){
					piece.appendChild(grid)
					grid = document.createElement('div')
					grid.className = "grid" 
				}

				var outItemE = document.createElement('div')
				outItemE.className = "unit half"
				outItemE.innerHTML = item.out[i].name + "： "
				
				var input = document.createElement('input')
				input.type = item.out[i].type
				input.id = item.out[i].id
				//input.readonly = "readonly"
				input.setAttribute("readonly","readonly")

				outItemE.appendChild(input)

				outItemE.innerHTML += " " + item.out[i].unit

				grid.appendChild(outItemE)

				if(i == len - 1) piece.appendChild(grid)
			}

			grid = document.createElement('div')
			grid.className = "grid"
			var descript = document.createElement('div')
			descript.className = "unit whole small"
			descript.innerHTML = item.descript
			grid.appendChild(descript)
			piece.appendChild(grid)

			content.appendChild(piece)
		}
	})
	
	if(index == "管道"){
		addDN_THKOption()
		addSCH_THKOption()
	}

}


function addDN_THKOption(){
	var dothk = document.getElementById("DN_THK")

	for(var key in PipeThk){
		if(key == "SCH") continue 
		var option = document.createElement("option")
		option.value = key
		option.innerHTML = key
		dothk.appendChild(option)
	}
}

function addSCH_THKOption(){
	var schthk = document.getElementById("SCH_THK")

	for(var i = 1; i < PipeThk.SCH.length; i++){
		var option = document.createElement("option")
		option.value = i
		option.innerHTML = PipeThk.SCH[i]
		schthk.appendChild(option)
	}
}